Backup of original images moved to avoid conflicts.

Files:
- i1.jpg
- i2.jpg

If you need to restore them, move the files back to the parent folder.